const mysql =
  require("mysql2/promise");

const databaseConfig =
  require("../config/database");

const pool =
  mysql.createPool(databaseConfig);

const testDatabaseConnection =
  async () => {
    let connection;

    try {
      connection =
        await pool.getConnection();

      const [rows] =
        await connection.query(`
          SELECT
            DATABASE() AS databaseName,
            VERSION() AS mysqlVersion,
            NOW() AS connectedAt
        `);

      const databaseInfo =
        rows[0];

      console.log(
        "MySQL connected successfully."
      );

      console.log(
        `Database: ${
          databaseInfo.databaseName
        }`
      );

      console.log(
        `MySQL version: ${
          databaseInfo.mysqlVersion
        }`
      );

      return databaseInfo;
    } catch (error) {
      console.error(
        "MySQL connection failed:"
      );

      console.error(
        `Code: ${
          error.code || "UNKNOWN"
        }`
      );

      console.error(
        `Message: ${error.message}`
      );

      throw error;
    } finally {
      if (connection) {
        connection.release();
      }
    }
  };

const closeDatabaseConnection =
  async () => {
    try {
      await pool.end();

      console.log(
        "MySQL connection pool closed."
      );
    } catch (error) {
      console.error(
        "Unable to close MySQL pool:",
        error.message
      );
    }
  };

module.exports = {
  pool,
  testDatabaseConnection,
  closeDatabaseConnection,
};