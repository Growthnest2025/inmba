"use strict";

/**
 * Cloudflare D1 database helper.
 * The Worker passes env into this helper.
 */

function getD1Database(env) {
  if (!env || !env.inmba_db) {
    throw new Error(
      "Cloudflare D1 binding 'inmba_db' is missing."
    );
  }

  return env.inmba_db;
}

async function testD1Connection(env) {
  const db = getD1Database(env);

  const result = await db
    .prepare("SELECT 1 AS connected")
    .first();

  return {
    success: result?.connected === 1,
    database: "inmba-db",
    result,
  };
}

module.exports = {
  getD1Database,
  testD1Connection,
};