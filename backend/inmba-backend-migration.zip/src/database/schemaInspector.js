const fs =
  require("fs/promises");

const path =
  require("path");

const mysql =
  require("mysql2/promise");

const {
  REQUIRED_DATABASE_SCHEMA,
} = require(
  "../constants/databaseSchema"
);

let inspectorConnection =
  null;

const RETRYABLE_ERROR_CODES =
  new Set([
    "ECONNRESET",
    "PROTOCOL_CONNECTION_LOST",
    "ETIMEDOUT",
    "EPIPE",
  ]);

const wait = (milliseconds) => {
  return new Promise(
    (resolve) => {
      setTimeout(
        resolve,
        milliseconds
      );
    }
  );
};

const getInspectorConfig = () => {
  return {
    host:
      process.env.DB_HOST ||
      "127.0.0.1",

    port:
      Number(
        process.env.DB_PORT
      ) ||
      3307,

    user:
      process.env.DB_USER ||
      "root",

    password:
      process.env.DB_PASSWORD ||
      "",

    database:
      process.env.DB_NAME ||
      "inmba",

    connectTimeout:
      20000,

    enableKeepAlive:
      true,

    keepAliveInitialDelay:
      0,

    dateStrings:
      true,

    charset:
      "utf8mb4",

    namedPlaceholders:
      true,
  };
};

const openInspectorConnection =
  async () => {
    if (
      inspectorConnection
    ) {
      try {
        await inspectorConnection
          .ping();

        return inspectorConnection;
      } catch (error) {
        inspectorConnection =
          null;
      }
    }

    inspectorConnection =
      await mysql.createConnection(
        getInspectorConfig()
      );

    await inspectorConnection.query(
      `
        SET SESSION
          net_read_timeout = 120,
          net_write_timeout = 120
      `
    );

    return inspectorConnection;
  };

const discardInspectorConnection =
  () => {
    if (
      inspectorConnection
    ) {
      try {
        inspectorConnection
          .destroy();
      } catch (error) {
        // Connection already closed.
      }
    }

    inspectorConnection =
      null;
  };

const closeInspectorConnection =
  async () => {
    if (
      !inspectorConnection
    ) {
      return;
    }

    try {
      await inspectorConnection
        .end();
    } catch (error) {
      // Connection may already be reset.
    } finally {
      inspectorConnection =
        null;
    }
  };

const runInspectorQuery =
  async (
    sql,
    parameters = [],
    queryName =
      "database query"
  ) => {
    const maximumAttempts =
      3;

    for (
      let attempt = 1;
      attempt <=
        maximumAttempts;
      attempt += 1
    ) {
      try {
        const connection =
          await openInspectorConnection();

        return await connection.query(
          sql,
          parameters
        );
      } catch (error) {
        const canRetry =
          RETRYABLE_ERROR_CODES
            .has(error.code) &&
          attempt <
            maximumAttempts;

        if (!canRetry) {
          error.message =
            `${queryName} failed: ${error.message}`;

          throw error;
        }

        console.warn(
          `${queryName} connection reset. Retrying ${attempt}/${maximumAttempts - 1}...`
        );

        discardInspectorConnection();

        await wait(
          attempt * 1000
        );
      }
    }

    throw new Error(
      `${queryName} failed after retries.`
    );
  };

const escapeIdentifier =
  (identifier) => {
    const safeIdentifier =
      String(identifier)
        .replaceAll(
          "`",
          "``"
        );

    return `\`${safeIdentifier}\``;
  };

const getDatabaseTables =
  async () => {
    const databaseName =
      process.env.DB_NAME ||
      "inmba";

    const [rows] =
      await runInspectorQuery(
        `
          SELECT
            TABLE_NAME AS tableName,
            ENGINE AS engine,
            TABLE_COLLATION AS collation,
            TABLE_ROWS AS estimatedRows,
            CREATE_TIME AS createdAt,
            UPDATE_TIME AS updatedAt
          FROM
            information_schema.tables
          WHERE
            table_schema = ?
            AND table_type = 'BASE TABLE'
          ORDER BY
            table_name ASC
        `,
        [
          databaseName,
        ],
        "Load database tables"
      );

    return rows;
  };

const getTableColumns =
  async (
    tableName
  ) => {
    const databaseName =
      process.env.DB_NAME ||
      "inmba";

    const [rows] =
      await runInspectorQuery(
        `
          SELECT
            ORDINAL_POSITION AS position,
            COLUMN_NAME AS columnName,
            COLUMN_TYPE AS columnType,
            DATA_TYPE AS dataType,
            IS_NULLABLE AS isNullable,
            COLUMN_DEFAULT AS defaultValue,
            COLUMN_KEY AS columnKey,
            EXTRA AS extra,
            CHARACTER_SET_NAME AS characterSet,
            COLLATION_NAME AS collation
          FROM
            information_schema.columns
          WHERE
            table_schema = ?
            AND table_name = ?
          ORDER BY
            ordinal_position ASC
        `,
        [
          databaseName,
          tableName,
        ],
        `Load ${tableName} columns`
      );

    return rows;
  };

const getTableIndexes =
  async (
    tableName
  ) => {
    const databaseName =
      process.env.DB_NAME ||
      "inmba";

    const [rows] =
      await runInspectorQuery(
        `
          SELECT
            INDEX_NAME AS indexName,
            NON_UNIQUE AS nonUnique,
            SEQ_IN_INDEX AS sequence,
            COLUMN_NAME AS columnName,
            COLLATION AS collation,
            CARDINALITY AS cardinality,
            INDEX_TYPE AS indexType
          FROM
            information_schema.statistics
          WHERE
            table_schema = ?
            AND table_name = ?
          ORDER BY
            index_name ASC,
            seq_in_index ASC
        `,
        [
          databaseName,
          tableName,
        ],
        `Load ${tableName} indexes`
      );

    return rows;
  };

const getTableForeignKeys =
  async (
    tableName
  ) => {
    const databaseName =
      process.env.DB_NAME ||
      "inmba";

    const [rows] =
      await runInspectorQuery(
        `
          SELECT
            CONSTRAINT_NAME AS constraintName,
            COLUMN_NAME AS columnName,
            REFERENCED_TABLE_NAME AS referencedTable,
            REFERENCED_COLUMN_NAME AS referencedColumn
          FROM
            information_schema.key_column_usage
          WHERE
            table_schema = ?
            AND table_name = ?
            AND referenced_table_name IS NOT NULL
          ORDER BY
            constraint_name ASC,
            ordinal_position ASC
        `,
        [
          databaseName,
          tableName,
        ],
        `Load ${tableName} foreign keys`
      );

    return rows;
  };

const getCreateTableStatement =
  async (
    tableName
  ) => {
    const escapedTableName =
      escapeIdentifier(
        tableName
      );

    const [rows] =
      await runInspectorQuery(
        `SHOW CREATE TABLE ${escapedTableName}`,
        [],
        `Load ${tableName} create statement`
      );

    if (!rows.length) {
      return null;
    }

    return (
      rows[0][
        "Create Table"
      ] ||
      Object.values(
        rows[0]
      )[1] ||
      null
    );
  };

const getTableRowCount =
  async (
    tableName
  ) => {
    const escapedTableName =
      escapeIdentifier(
        tableName
      );

    const [rows] =
      await runInspectorQuery(
        `
          SELECT
            COUNT(*) AS rowCount
          FROM
            ${escapedTableName}
        `,
        [],
        `Count ${tableName} rows`
      );

    return Number(
      rows[0]
        ?.rowCount ||
      0
    );
  };

const validateDatabaseSchema =
  (
    actualTables
  ) => {
    const missingTables =
      [];

    const missingColumns =
      {};

    const extraColumns =
      {};

    for (
      const [
        tableName,
        expectedColumns,
      ] of Object.entries(
        REQUIRED_DATABASE_SCHEMA
      )
    ) {
      const actualTable =
        actualTables[
          tableName
        ];

      if (!actualTable) {
        missingTables.push(
          tableName
        );

        missingColumns[
          tableName
        ] = [
          ...expectedColumns,
        ];

        continue;
      }

      const actualColumnNames =
        actualTable.columns.map(
          (column) =>
            column.columnName
        );

      const actualColumnSet =
        new Set(
          actualColumnNames
        );

      const expectedColumnSet =
        new Set(
          expectedColumns
        );

      const currentMissingColumns =
        expectedColumns.filter(
          (columnName) =>
            !actualColumnSet.has(
              columnName
            )
        );

      const currentExtraColumns =
        actualColumnNames.filter(
          (columnName) =>
            !expectedColumnSet.has(
              columnName
            )
        );

      if (
        currentMissingColumns
          .length
      ) {
        missingColumns[
          tableName
        ] =
          currentMissingColumns;
      }

      if (
        currentExtraColumns
          .length
      ) {
        extraColumns[
          tableName
        ] =
          currentExtraColumns;
      }
    }

    return {
      valid:
        missingTables.length ===
          0 &&
        Object.keys(
          missingColumns
        ).length === 0,

      missingTables,

      missingColumns,

      extraColumns,
    };
  };

const inspectDatabaseSchema =
  async (
    onProgress =
      () => {}
  ) => {
    const [versionRows] =
      await runInspectorQuery(
        `
          SELECT
            DATABASE() AS databaseName,
            VERSION() AS databaseVersion,
            NOW() AS inspectedAt
        `,
        [],
        "Load database information"
      );

    const tableMetadata =
      await getDatabaseTables();

    const tables =
      {};

    for (
      let index = 0;
      index <
        tableMetadata.length;
      index += 1
    ) {
      const table =
        tableMetadata[index];

      const tableName =
        table.tableName;

      onProgress({
        current:
          index + 1,

        total:
          tableMetadata.length,

        tableName,
      });

      /*
        Queries parallel-ஆ execute
        செய்யாமல் sequential-ஆ
        run செய்கிறோம்.
      */
      const columns =
        await getTableColumns(
          tableName
        );

      const indexes =
        await getTableIndexes(
          tableName
        );

      const foreignKeys =
        await getTableForeignKeys(
          tableName
        );

      const createStatement =
        await getCreateTableStatement(
          tableName
        );

      const rowCount =
        await getTableRowCount(
          tableName
        );

      tables[
        tableName
      ] = {
        metadata: {
          engine:
            table.engine,

          collation:
            table.collation,

          estimatedRows:
            Number(
              table.estimatedRows ||
              0
            ),

          actualRowCount:
            rowCount,

          createdAt:
            table.createdAt ||
            null,

          updatedAt:
            table.updatedAt ||
            null,
        },

        columns,

        indexes,

        foreignKeys,

        createStatement,
      };
    }

    return {
      generatedAt:
        new Date()
          .toISOString(),

      database: {
        name:
          versionRows[0]
            .databaseName,

        version:
          versionRows[0]
            .databaseVersion,

        serverTime:
          versionRows[0]
            .inspectedAt,

        tableCount:
          Object.keys(
            tables
          ).length,
      },

      validation:
        validateDatabaseSchema(
          tables
        ),

      tables,
    };
  };

const writeDatabaseSchemaReport =
  async (
    report,
    outputFile
  ) => {
    const outputPath =
      path.resolve(
        outputFile
      );

    await fs.mkdir(
      path.dirname(
        outputPath
      ),
      {
        recursive:
          true,
      }
    );

    await fs.writeFile(
      outputPath,
      JSON.stringify(
        report,
        null,
        2
      ),
      "utf8"
    );

    return outputPath;
  };

module.exports = {
  inspectDatabaseSchema,
  writeDatabaseSchemaReport,
  closeInspectorConnection,
};