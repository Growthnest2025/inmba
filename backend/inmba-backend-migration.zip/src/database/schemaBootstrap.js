const {
  executeQuery,
} = require(
  "../repositories/auth.repository"
);

const {
  SCHEMA_VERSION,
  SCHEMA_MIGRATION_NAME,
  TABLE_SCHEMAS,
  buildCreateTableSql,
} = require(
  "./schema.definition"
);

let latestSchemaReport =
  null;

/* =========================
   RESULT NORMALIZATION
========================= */

const normalizeRows = (
  result
) => {
  if (
    Array.isArray(result) &&
    Array.isArray(result[0])
  ) {
    return result[0];
  }

  return Array.isArray(result)
    ? result
    : [];
};

/* =========================
   IDENTIFIER SAFETY
========================= */

const quoteIdentifier = (
  value
) => {
  const identifier =
    String(value || "");

  if (
    !/^[A-Za-z0-9_]+$/.test(
      identifier
    )
  ) {
    throw new Error(
      `Unsafe SQL identifier: ${identifier}`
    );
  }

  return `\`${identifier}\``;
};

/* =========================
   DATABASE INFORMATION
========================= */

const getDatabaseInfo =
  async () => {
    const result =
      await executeQuery(
        `
          SELECT
            DATABASE() AS database_name,
            VERSION() AS database_version
        `
      );

    const rows =
      normalizeRows(
        result
      );

    return {
      database_name:
        rows?.[0]
          ?.database_name ||
        null,

      database_version:
        rows?.[0]
          ?.database_version ||
        null,
    };
  };

/* =========================
   TABLE CHECK
========================= */

const tableExists =
  async (
    tableName
  ) => {
    const result =
      await executeQuery(
        `
          SELECT
            TABLE_NAME

          FROM
            INFORMATION_SCHEMA.TABLES

          WHERE
            TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = ?

          LIMIT 1
        `,
        [
          tableName,
        ]
      );

    return (
      normalizeRows(
        result
      ).length >
      0
    );
  };

/* =========================
   TABLE COLUMNS
========================= */

const getTableColumns =
  async (
    tableName
  ) => {
    const result =
      await executeQuery(
        `
          SELECT
            COLUMN_NAME

          FROM
            INFORMATION_SCHEMA.COLUMNS

          WHERE
            TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = ?
        `,
        [
          tableName,
        ]
      );

    return new Set(
      normalizeRows(
        result
      ).map(
        (
          row
        ) =>
          row.COLUMN_NAME ||
          row.column_name
      )
    );
  };

/* =========================
   TABLE INDEXES
========================= */

const getTableIndexes =
  async (
    tableName
  ) => {
    const result =
      await executeQuery(
        `
          SELECT
            INDEX_NAME,
            NON_UNIQUE,
            SEQ_IN_INDEX,
            COLUMN_NAME

          FROM
            INFORMATION_SCHEMA.STATISTICS

          WHERE
            TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = ?

          ORDER BY
            INDEX_NAME,
            SEQ_IN_INDEX
        `,
        [
          tableName,
        ]
      );

    const indexes =
      new Map();

    for (
      const row of normalizeRows(
        result
      )
    ) {
      const indexName =
        row.INDEX_NAME ||
        row.index_name;

      if (
        !indexes.has(
          indexName
        )
      ) {
        indexes.set(
          indexName,
          {
            name:
              indexName,

            unique:
              Number(
                row.NON_UNIQUE ??
                row.non_unique
              ) === 0,

            columns:
              [],
          }
        );
      }

      indexes
        .get(indexName)
        .columns.push(
          row.COLUMN_NAME ||
          row.column_name
        );
    }

    return indexes;
  };

/* =========================
   INDEX COMPARISON
========================= */

const arraysEqual = (
  first,
  second
) => {
  if (
    first.length !==
    second.length
  ) {
    return false;
  }

  return first.every(
    (
      value,
      index
    ) =>
      value ===
      second[index]
  );
};

const hasEquivalentIndex = (
  existingIndexes,
  requestedIndex
) => {
  for (
    const existingIndex of
      existingIndexes.values()
  ) {
    if (
      requestedIndex.unique &&
      !existingIndex.unique
    ) {
      continue;
    }

    if (
      arraysEqual(
        existingIndex.columns,
        requestedIndex.columns
      )
    ) {
      return true;
    }
  }

  return false;
};

/* =========================
   UNIQUE DUPLICATE CHECK
========================= */

const findUniqueDuplicate =
  async (
    tableName,
    indexConfig
  ) => {
    if (
      !indexConfig.unique ||
      indexConfig.columns
        .length !== 1
    ) {
      return null;
    }

    const columnName =
      indexConfig.columns[0];

    const tableSql =
      quoteIdentifier(
        tableName
      );

    const columnSql =
      quoteIdentifier(
        columnName
      );

    const emptyCondition =
      indexConfig.ignoreEmpty
        ? `
            AND TRIM(
              CAST(
                ${columnSql}
                AS CHAR
              )
            ) <> ''
          `
        : "";

    const result =
      await executeQuery(
        `
          SELECT
            ${columnSql}
              AS duplicate_value,

            COUNT(*)
              AS duplicate_count

          FROM
            ${tableSql}

          WHERE
            ${columnSql}
              IS NOT NULL

            ${emptyCondition}

          GROUP BY
            ${columnSql}

          HAVING
            COUNT(*) > 1

          LIMIT 1
        `
      );

    const rows =
      normalizeRows(
        result
      );

    return rows[0] ||
      null;
  };

/* =========================
   ENSURE TABLE
========================= */

const ensureTable =
  async (
    tableName,
    schema,
    report
  ) => {
    const existedBefore =
      await tableExists(
        tableName
      );

    await executeQuery(
      buildCreateTableSql(
        tableName,
        schema
      )
    );

    if (
      !existedBefore
    ) {
      report
        .tables_created
        .push(
          tableName
        );
    }
  };

/* =========================
   ENSURE COLUMNS
========================= */

const ensureColumns =
  async (
    tableName,
    schema,
    report
  ) => {
    const existingColumns =
      await getTableColumns(
        tableName
      );

    for (
      const [
        columnName,
        columnConfig,
      ] of Object.entries(
        schema.columns
      )
    ) {
      if (
        existingColumns.has(
          columnName
        )
      ) {
        continue;
      }

      if (
        columnConfig
          .addIfMissing ===
        false
      ) {
        throw new Error(
          `Critical primary column ${tableName}.${columnName} is missing. Automatic addition is unsafe.`
        );
      }

      const tableSql =
        quoteIdentifier(
          tableName
        );

      const columnSql =
        quoteIdentifier(
          columnName
        );

      try {
        await executeQuery(
          `
            ALTER TABLE
              ${tableSql}

            ADD COLUMN
              ${columnSql}
              ${columnConfig.definition}
          `
        );

        report
          .columns_added
          .push(
            `${tableName}.${columnName}`
          );
      } catch (error) {
        if (
          error?.code !==
          "ER_DUP_FIELDNAME"
        ) {
          throw error;
        }
      }
    }
  };

/* =========================
   ENSURE INDEXES
========================= */

const ensureIndexes =
  async (
    tableName,
    schema,
    report
  ) => {
    let existingIndexes =
      await getTableIndexes(
        tableName
      );

    for (
      const indexConfig of
        schema.indexes
    ) {
      if (
        existingIndexes.has(
          indexConfig.name
        ) ||
        hasEquivalentIndex(
          existingIndexes,
          indexConfig
        )
      ) {
        continue;
      }

      const duplicate =
        await findUniqueDuplicate(
          tableName,
          indexConfig
        );

      if (
        duplicate
      ) {
        const warning =
          `Skipped unique index ${indexConfig.name}: duplicate value exists in ${tableName}.${indexConfig.columns[0]}.`;

        report
          .warnings
          .push(
            warning
          );

        report
          .indexes_skipped
          .push({
            table:
              tableName,

            index:
              indexConfig.name,

            reason:
              "duplicate_data",
          });

        continue;
      }

      const tableSql =
        quoteIdentifier(
          tableName
        );

      const indexSql =
        quoteIdentifier(
          indexConfig.name
        );

      const columnsSql =
        indexConfig.columns
          .map(
            quoteIdentifier
          )
          .join(", ");

      const uniqueSql =
        indexConfig.unique
          ? "UNIQUE "
          : "";

      try {
        await executeQuery(
          `
            ALTER TABLE
              ${tableSql}

            ADD ${uniqueSql}INDEX
              ${indexSql}
              (${columnsSql})
          `
        );

        report
          .indexes_added
          .push(
            `${tableName}.${indexConfig.name}`
          );

        existingIndexes =
          await getTableIndexes(
            tableName
          );
      } catch (error) {
        if (
          error?.code ===
            "ER_DUP_KEYNAME" ||
          error?.code ===
            "ER_DUP_ENTRY"
        ) {
          report
            .warnings
            .push(
              `Index ${indexConfig.name} was not added: ${error.message}`
            );

          continue;
        }

        throw error;
      }
    }
  };

/* =========================
   SCHEMA INSPECTION
========================= */

const inspectSchema =
  async () => {
    const database =
      await getDatabaseInfo();

    const missingTables =
      [];

    const missingColumns =
      [];

    const missingIndexes =
      [];

    const tableSummary =
      {};

    for (
      const [
        tableName,
        schema,
      ] of Object.entries(
        TABLE_SCHEMAS
      )
    ) {
      const exists =
        await tableExists(
          tableName
        );

      if (
        !exists
      ) {
        missingTables.push(
          tableName
        );

        continue;
      }

      const columns =
        await getTableColumns(
          tableName
        );

      const indexes =
        await getTableIndexes(
          tableName
        );

      const tableMissingColumns =
        Object.keys(
          schema.columns
        ).filter(
          (
            columnName
          ) =>
            !columns.has(
              columnName
            )
        );

      const tableMissingIndexes =
        schema.indexes
          .filter(
            (
              indexConfig
            ) =>
              !indexes.has(
                indexConfig.name
              ) &&
              !hasEquivalentIndex(
                indexes,
                indexConfig
              )
          )
          .map(
            (
              indexConfig
            ) =>
              indexConfig.name
          );

      for (
        const columnName of
          tableMissingColumns
      ) {
        missingColumns.push(
          `${tableName}.${columnName}`
        );
      }

      for (
        const indexName of
          tableMissingIndexes
      ) {
        missingIndexes.push(
          `${tableName}.${indexName}`
        );
      }

      tableSummary[
        tableName
      ] = {
        exists:
          true,

        columns:
          columns.size,

        indexes:
          indexes.size,

        missing_columns:
          tableMissingColumns,

        missing_indexes:
          tableMissingIndexes,
      };
    }

    return {
      schema_version:
        SCHEMA_VERSION,

      database,

      ready:
        missingTables.length ===
          0 &&
        missingColumns.length ===
          0,

      fully_indexed:
        missingIndexes.length ===
        0,

      missing_tables:
        missingTables,

      missing_columns:
        missingColumns,

      missing_indexes:
        missingIndexes,

      tables:
        tableSummary,

      checked_at:
        new Date()
          .toISOString(),
    };
  };

/* =========================
   MIGRATION HISTORY
========================= */

const recordMigration =
  async (
    report
  ) => {
    const safeReport = {
      schema_version:
        report.schema_version,

      tables_created:
        report.tables_created,

      columns_added:
        report.columns_added,

      indexes_added:
        report.indexes_added,

      indexes_skipped:
        report.indexes_skipped,

      warnings:
        report.warnings,

      completed_at:
        report.completed_at,
    };

    await executeQuery(
      `
        INSERT INTO
          schema_migrations
        (
          migration_name,
          migration_version,
          details_json,
          applied_at,
          last_verified_at
        )
        VALUES
        (
          ?,
          ?,
          ?,
          CURRENT_TIMESTAMP,
          CURRENT_TIMESTAMP
        )

        ON DUPLICATE KEY UPDATE
          migration_version =
            VALUES(
              migration_version
            ),

          details_json =
            VALUES(
              details_json
            ),

          last_verified_at =
            CURRENT_TIMESTAMP
      `,
      [
        SCHEMA_MIGRATION_NAME,
        SCHEMA_VERSION,
        JSON.stringify(
          safeReport
        ),
      ]
    );
  };

/* =========================
   RUN BOOTSTRAP
========================= */

const runSchemaBootstrap =
  async (
    options = {}
  ) => {
    const logger =
      options.logger ||
      console;

    const startedAt =
      new Date();

    const database =
      await getDatabaseInfo();

    const report = {
      migration_name:
        SCHEMA_MIGRATION_NAME,

      schema_version:
        SCHEMA_VERSION,

      database,

      started_at:
        startedAt
          .toISOString(),

      completed_at:
        null,

      tables_created:
        [],

      columns_added:
        [],

      indexes_added:
        [],

      indexes_skipped:
        [],

      warnings:
        [],

      verification:
        null,
    };

    logger.log(
      `[Schema] Starting schema ${SCHEMA_VERSION} on ${database.database_name}.`
    );

    /*
      schema_migrations must be
      created first.
    */

    const migrationSchema =
      TABLE_SCHEMAS
        .schema_migrations;

    await ensureTable(
      "schema_migrations",
      migrationSchema,
      report
    );

    await ensureColumns(
      "schema_migrations",
      migrationSchema,
      report
    );

    await ensureIndexes(
      "schema_migrations",
      migrationSchema,
      report
    );

    for (
      const [
        tableName,
        schema,
      ] of Object.entries(
        TABLE_SCHEMAS
      )
    ) {
      if (
        tableName ===
        "schema_migrations"
      ) {
        continue;
      }

      console.log(
        `[Schema] Checking table: ${tableName}`
      );

      await ensureTable(
        tableName,
        schema,
        report
      );

      await ensureColumns(
        tableName,
        schema,
        report
      );

      await ensureIndexes(
        tableName,
        schema,
        report
      );
    }

    report.verification =
      await inspectSchema();

    report.completed_at =
      new Date()
        .toISOString();

    if (
      !report.verification
        .ready
    ) {
      const error =
        new Error(
          "Database schema verification failed."
        );

      error.schemaReport =
        report;

      throw error;
    }

    await recordMigration(
      report
    );

    latestSchemaReport =
      report;

    logger.log(
      `[Schema] Complete. Tables created: ${report.tables_created.length}, columns added: ${report.columns_added.length}, indexes added: ${report.indexes_added.length}.`
    );

    for (
      const warning of
        report.warnings
    ) {
      logger.warn(
        `[Schema warning] ${warning}`
      );
    }

    return report;
  };

/* =========================
   LATEST REPORT
========================= */

const getLatestSchemaReport =
  () => {
    return latestSchemaReport;
  };

module.exports = {
  normalizeRows,
  quoteIdentifier,
  getDatabaseInfo,
  tableExists,
  getTableColumns,
  getTableIndexes,
  arraysEqual,
  hasEquivalentIndex,
  findUniqueDuplicate,
  ensureTable,
  ensureColumns,
  ensureIndexes,
  inspectSchema,
  recordMigration,
  runSchemaBootstrap,
  getLatestSchemaReport,
};